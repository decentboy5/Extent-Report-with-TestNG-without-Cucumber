package com.Reltio.TestScripts;

import org.openqa.selenium.WebDriver;
import org.testng.Reporter;
import org.testng.annotations.Test;
import org.testng.log4testng.Logger;
import org.w3c.css.sac.SiblingSelector;

import com.Reltio.CommonClasses.DriverClass;
import com.Reltio.CommonClasses.ExtentReportBase;
import com.Reltio.CommonClasses.WaitClass;
import com.Reltio.PageFactory.LoginPage;
import com.Reltio.PageFactory.SearchMenu;
import com.aventstack.extentreports.Status;

public class SampleTestCase extends ExtentReportBase {

	
WebDriver driver;
	@Test
	public void Login_With_Valid_Credentials() throws Exception {
		test = extent.createTest("Verify Search functionluty in google.com");
		driver = DriverClass.getDriver();
		LoginPage obj = new LoginPage(driver);

		obj.SeachBar("Hellooooooooo");
		Reporter.log("is not enabled");
		WaitClass.waitforSeconds(5);
		test.log(Status.PASS, "**** Verify Seach Functionality Passed ****");

	}
}
